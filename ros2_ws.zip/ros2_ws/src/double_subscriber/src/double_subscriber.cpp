#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float64.hpp"
#include "example_interfaces/srv/set_bool.hpp"

class DoubleSubscriber : public rclcpp::Node {
public:
    DoubleSubscriber() : Node("double_subscriber"), last_received_double_(0.0) {
        subscriber_ = this->create_subscription<std_msgs::msg::Float64>(
            "double_topic", 10,
            std::bind(&DoubleSubscriber::topic_callback, this, std::placeholders::_1));

        service_ = this->create_service<example_interfaces::srv::SetBool>(
            "double_service",
            std::bind(&DoubleSubscriber::service_callback, this, 
                      std::placeholders::_1, std::placeholders::_2));
    }

private:
    void topic_callback(const std_msgs::msg::Float64::SharedPtr msg) {
        last_received_double_ = msg->data;
        RCLCPP_INFO(this->get_logger(), "Received: '%f'", msg->data); // 添加日志输出
    }

    void service_callback(const std::shared_ptr<example_interfaces::srv::SetBool::Request> /* request */,
                          std::shared_ptr<example_interfaces::srv::SetBool::Response> response) {
        response->success = true;
        response->message = std::to_string(last_received_double_ * 2);
    }

    rclcpp::Subscription<std_msgs::msg::Float64>::SharedPtr subscriber_;
    rclcpp::Service<example_interfaces::srv::SetBool>::SharedPtr service_;
    double last_received_double_;
};

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<DoubleSubscriber>());
    rclcpp::shutdown();
    return 0;
}
