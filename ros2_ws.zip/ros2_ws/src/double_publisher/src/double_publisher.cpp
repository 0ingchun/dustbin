#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float64.hpp"

class DoublePublisher : public rclcpp::Node {
public:
    DoublePublisher() : Node("double_publisher"), count_(0.0) {
        publisher_ = this->create_publisher<std_msgs::msg::Float64>("double_topic", 10);
        timer_ = this->create_wall_timer(
            std::chrono::seconds(1), 
            std::bind(&DoublePublisher::timer_callback, this));
    }

private:
    void timer_callback() {
    std_msgs::msg::Float64 message;
    message.data = count_;
    RCLCPP_INFO(this->get_logger(), "Publishing: '%f'", message.data); // 添加日志输出
    publisher_->publish(message);
    count_ += 0.5;
    }


    rclcpp::Publisher<std_msgs::msg::Float64>::SharedPtr publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
    double count_;
};

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<DoublePublisher>());
    rclcpp::shutdown();
    return 0;
}
